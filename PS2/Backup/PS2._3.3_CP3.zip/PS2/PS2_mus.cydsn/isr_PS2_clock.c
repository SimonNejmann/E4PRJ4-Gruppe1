#include <project.h>
#include <functions.h>

CY_ISR(PS2_interrupt) {
    
//    ISR_getMouseData();
//    isr_PS2_clock_ClearPending();
}
