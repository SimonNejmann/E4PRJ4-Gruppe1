/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "`$INSTANCE_NAME`_defs.h"


#define `$INSTANCE_NAME`_Forward_cnt `$INSTANCE_NAME`_Forward_A0_REG
#define `$INSTANCE_NAME`_Backward_cnt `$INSTANCE_NAME`_Forward_A1_REG
/* [] END OF FILE */
