#include <main.h>

void run_back(uint8 ang_1, uint8 speed_1)
{
    State_Count_reset_Reg = ang_1;
    State_Count_val_Reg = speed_1;
}