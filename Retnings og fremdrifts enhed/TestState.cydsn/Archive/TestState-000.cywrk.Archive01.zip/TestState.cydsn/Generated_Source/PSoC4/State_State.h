/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "State_defs.h"
#define State_Period_PWM_Reg State_pwm_block_D0_REG
#define State_Compare_PWM_Reg State_pwm_block_D1_REG

#define State_Count_val_Reg State_count_block_D0_REG
#define State_Count_reset_Reg State_count_block_D1_REG
/* [] END OF FILE */
