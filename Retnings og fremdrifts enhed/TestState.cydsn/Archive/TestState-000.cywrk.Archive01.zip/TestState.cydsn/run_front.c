#include <main.h>

void run_front(uint8 ang_2, uint8 speed_2)
{
    State_Period_PWM_Reg = ang_2;
    State_Compare_PWM_Reg = speed_2;
}
