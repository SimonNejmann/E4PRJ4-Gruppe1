/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "State_defs.h"


#define State_Forward_cnt State_Forward_A0_REG
#define State_Backward_cnt State_Forward_A1_REG
/* [] END OF FILE */
