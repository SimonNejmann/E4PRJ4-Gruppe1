#include <main.h>

uint8 run_back(uint8 ang, uint8 speed)
{
    uint8 i;
    
   for(i=0; i < ang ; i++){
    Green_Led_Write(1);
    CyDelay(100);
    Green_Led_Write(0);
    Gul_Led_Write(1);
    CyDelay(100);
    Gul_Led_Write(0);
    Red_Led_Write(1);
    CyDelay(100);
    Red_Led_Write(0);
    Green_Led_1_Write(1);
    CyDelay(100);
    Green_Led_1_Write(0);
    CyDelay(100);
   }
 return 0;   
}