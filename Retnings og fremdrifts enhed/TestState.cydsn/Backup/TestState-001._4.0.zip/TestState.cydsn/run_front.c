#include <main.h>

uint8 run_front(uint8 ang, uint8 speed, uint8 ang2, uint8 speed2)
{
    
    if(ang > 0 && speed == 0)
    {
        State_Forward_cnt = ang;
        State_CtrlReg_Dir_Write(1);
        State_CtrlReg_Run_Write(1);
    }
      
    
    else if(speed > 0 && ang == 0)
    {
        State_Forward_cnt = speed;
        State_CtrlReg_Dir_Write(2);
        State_CtrlReg_Run_Write(1);
    }
    
    else if(ang2 > 0)
    {    uint8 i;
    
    for(i=0; i < ang2 ; i++){
    Green_Led_Write(1);
    CyDelay(100);
    Green_Led_Write(0);
    Gul_Led_Write(1);
    CyDelay(100);
    Gul_Led_Write(0);
    Red_Led_Write(1);
    CyDelay(100);
    Red_Led_Write(0);
    Green_Led_1_Write(1);
    CyDelay(100);
    Green_Led_1_Write(0);
    CyDelay(100);
   }
    }
    
    return 0;
}
    
